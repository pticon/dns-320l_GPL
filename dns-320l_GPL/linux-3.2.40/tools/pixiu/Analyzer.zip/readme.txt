NOTICE: This patch is only for internal development!

New supported processor:
1. ARMADA370
2. ARMADAXP

Usage:
1. Copy the Analyzer folder to the CPA analyzer folder, overwrite all files.
2. This patch can be used for both Linux and Windows version.
